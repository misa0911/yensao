<?php
require_once 'pdo.php';

/**
 * Thêm loại mới
 * @param String $ten_province là tên loại
 * @throws PDOException lỗi thêm mới
 */
function province_insert($Name,$Sort){
    $sql = "INSERT INTO province(Name,Sort) VALUES(?,?)";
    pdo_execute($sql, $Name,$Sort);
}
/**
 * Cập nhật tên loại
 * @param int $Id là mã loại cần cập nhật
 * @param String $ten_province là tên loại mới
 * @throws PDOException lỗi cập nhật
 */
function province_update($Name,$Sort,$Id){ // lưu ý phần này khóa chính luôn nằm đầu vidu Id
    $sql = "UPDATE province SET Name=?,Sort=? WHERE Id=?";
    pdo_execute($sql, $Name,$Sort,$Id);  // lưu ý phần này khóa chính luôn nằm cuối vidu Id
}
/**
 * Xóa một hoặc nhiều loại
 * @param mix $Id là mã loại hoặc mảng mã loại
 * @throws PDOException lỗi xóa
 */
function province_delete($Id){
    $sql = "DELETE FROM province WHERE Id=?";
    if(is_array($Id)){
        foreach ($Id as $ma) {
            pdo_execute($sql, $ma);
        }
    }
    else{
        pdo_execute($sql, $Id);
    }
}
/**
 * Truy vấn tất cả các loại
 * @return array mảng loại truy vấn được
 * @throws PDOException lỗi truy vấn
 */
function province_select_all(){
    $sql = "SELECT * FROM province ORDER BY Name DESC";
    return pdo_query($sql);
}


/**
 * Truy vấn một loại theo mã
 * @param int $Id là mã loại cần truy vấn
 * @return array mảng chứa thông tin của một loại
 * @throws PDOException lỗi truy vấn
 */
function province_select_by_id($Id){
    $sql = "SELECT * FROM province WHERE Id=?";
    return pdo_query_one($sql, $Id);
}

/**
 * Kiểm tra sự tồn tại của một loại
 * @param int $Id là mã loại cần kiểm tra
 * @return boolean có tồn tại hay không
 * @throws PDOException lỗi truy vấn
 */
//function province_exist($Id){
//    $sql = "SELECT count(*) FROM province WHERE Id=?";
//    return pdo_query_value($sql, $Id) > 0;
//}
//menu đa cấp
//function Menu($parent = 0,$space = '---', $trees = NULL){ 
//        if(!$trees){ $trees = array(); }
//	$sql = mysql_query("SELECT * FROM province WHERE parent = ".intval($parent)." ORDER BY Name"); 
//	while($rs = mysql_fetch_assoc($sql)){ 
//		$trees[] = array('Id'=>$rs['Id'],'Name'=>$space.$rs['Name']); 
//		$trees = Menu($rs['Id'],$space.'---',$trees); 
//	} 
//	return $trees; 
//}
?>