<?php

  require 'admin/headeradmin.php';
  require 'dao/pdo.php';



  pdo_get_connection();
  
  function exits_param($filedname){
  	return array_key_exists($filedname, $_REQUEST); // Dùng hàm request đọc các giá trị
  }
  if(exits_param("qlproduct")){
  	$VIEW_NAME = 'admin/qlproduct.php';
  }else if(exits_param("loadquanhuyen")){
  	$VIEW_NAME = 'admin/loadquanhuyen.php';
  }else if(exits_param("qlcustomer")){
  	$VIEW_NAME = 'admin/qlcustomer.php';
  }else if(exits_param("qlcomment")){
  	$VIEW_NAME = 'admin/qlcomment.php';
  }else if(exits_param("qlthongke")){
  	$VIEW_NAME = 'admin/qlthongke.php';
  }else if(exits_param("qlthuonghieu")){
    $VIEW_NAME = 'admin/qlthuonghieu.php';
  }elseif(exits_param("qlhinh")){
    $VIEW_NAME = 'admin/qlhinh.php';
  }else{
        $VIEW_NAME = 'admin/danhmuc.php';
  }
  require $VIEW_NAME;
?>