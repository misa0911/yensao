<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"> </script>
<script type="text/javascript">
function showLoading(){$("#div1").html("Đang xử lý....")}
function hideLoading(){$("#div1").html("")}
function ajaxselect()
{
var str=$("#tinh").val();
showLoading();
$.ajax({type:"POST",url:"admin/loadquan.php",data:"ss="+str,dataType:"json",timeout:8e4,
    error:function(){$("#div1").html("Server đang bận hoặc quá tải");return false},
    success:function(c){
    hideLoading();
    if(c.status==1){
    $("#div1").html(c.msg);
    }
    }});
};
</script>

<select name="tinh" id="tinh" onchange="ajaxselect(this.value);">
    <option value="0" selected>Chọn tỉnh/thành</option>
<!--     <option value="1" >HCM City</option>
      <option value="2" >Can Tho</option>
      <option value="3" >Da Nang</option>-->
    
<?php
    require 'dao/province.php';
    $ds=province_select_all();
    foreach ($ds as $ds) {
        extract($ds);
        echo '<option value="'.$Id.'">'.$Name.'</option>';
    }
?>
</select>
<div id="div1"></div>