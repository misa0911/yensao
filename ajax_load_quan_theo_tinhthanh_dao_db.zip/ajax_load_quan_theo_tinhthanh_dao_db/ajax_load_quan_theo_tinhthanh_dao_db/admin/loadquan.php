<?php
if($_POST["ss"]>0){
    require '../dao/pdo.php';
    $Idparent=$_POST["ss"];
    function city_select_all_Idparent($Idparent){
        $sql = "SELECT * FROM city WHERE Idparent=? ORDER BY Name DESC";
        return pdo_query($sql,$Idparent);
    }
    $mesaj = '<select name=\'huyen\' id=\'huyen\' ><option value=\'0\'>Chọn quận huyện ...</option>';
    $ds=city_select_all_Idparent($Idparent);
    foreach ($ds as $ds) {
        extract($ds);
        $mesaj .= '<option value=\''.$Id.'\'>'.$Name.'</option>';
    }
    $mesaj .= '</select>';
}

//if ($_POST["ss"]=="1") {
//$mesaj = '<select name=\'huyen\' id=\'huyen\' ><option value=\'1\'>huyen 1</option><option value=\'2\'>huyen 2</option></select>';
//}
//if ($_POST["ss"]=="2") {
//$mesaj = '<select name=\'huyen\' id=\'huyen\' ><option value=\'3\'>huyen 3</option><option value=\'4\'>huyen 4</option></select>';
//}
echo '{"status":1,"msg":"'.$mesaj.'"}';
?>